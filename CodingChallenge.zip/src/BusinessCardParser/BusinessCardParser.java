package BusinessCardParser;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Alex Loulou
 */
public class BusinessCardParser implements ContactInfo {

	public static final Pattern PATTERN_NOT_NAME = Pattern.compile("(?im)\\s*\\d.*|.*?\\d{2,}.*|.*?[~`@#\\$%\\^&\\*\\(\\)_+=:;\\\"'{}\\[\\]\\|\\\\<>\\?/+].*|.*\\s*,?\\s*INC\\s*$|\\s+LLC\\s*$", Pattern.DOTALL);
	public static final Pattern PATTERN_PROB_IS_OTHER = Pattern.compile("(?im)\\s*.*?(ENGINEER|TECHNOLOGIES|SYSTEMS|DEVELOPER|MANAGER|SOFTWARE)\\s*.*", Pattern.DOTALL);
	public static final Pattern PATTERN_EXPLICIT_NAME = Pattern.compile("(?im)\\s*Name\\s*?[: \t]\\s*(\\p{L}+[\\p{L}\\p{Pd}\\p{Zs}',]*\\p{L}+$|\\p{L}+)\\s*$", Pattern.DOTALL);
	public static final Pattern PATTERN_POSSIBLE_NAME = Pattern.compile("(?im)\\s*(\\p{L}+[\\p{L}\\p{Pd}\\p{Zs}',]*\\p{L}+$|\\p{L}+)\\s*$", Pattern.DOTALL);
	public static final Pattern PATTERN_EMAIL = Pattern.compile("(?im)\\s*(Email\\s*[:]?\\s*)?([a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+)\\s*", Pattern.DOTALL);
	public static final Pattern PATTERN_PHONE = Pattern.compile("(?im)\\s*(Phone\\s*:|Tel\\s*:|Telephone\\s*:|Mobile\\s*:)?\\s*\\+?\\s*([1-9]{1,4})?\\s*\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})\\s*", Pattern.DOTALL);

	private String name;
	private String phoneNumber;
	private String emailAddress;

	public static ContactInfo getContactInfo(String document) {
		return new BusinessCardParser(document);
	}

	public static String fmtNameLine(String line) {
		String name = null;
		if (line.trim().length() > 0) {
			String[] nameParts = line.trim().split("\\s*,\\s*", 2);
			if (nameParts.length == 2) {
				name = nameParts[1] + " " + nameParts[0];
			}
			else {
				name = nameParts[0];
			}
		}
		return name;
	}

	private BusinessCardParser(String document) {
		List<String> lines = new ArrayList<>(); //individual lines scanned from the document
		try (InputStream in = new ByteArrayInputStream(document.getBytes()); InputStreamReader isr = new InputStreamReader(in); LineNumberReader reader = new LineNumberReader(isr)) {
			String line;
			while ((line = reader.readLine()) != null) {
				if ((line = line.trim()).length() == 0) {
					continue; //skip empty lines
				}
				lines.add(line);
			}
		}
		catch (IOException e) {
		}

		List<String> possibleNameLines = new ArrayList<>();
		Matcher m;
		for (String line : lines) {
			//for each line, first get the easy explicit identifyers
			if (name == null) {
				m = PATTERN_EXPLICIT_NAME.matcher(line);
				if (m.find()) {
					if (m.groupCount() == 1) {
						name = fmtNameLine(m.group(1));
					}
					continue;
				}
			}
			if (emailAddress == null) {
				m = PATTERN_EMAIL.matcher(line);
				if (m.find()) {
					if (m.groupCount() == 2) {
						String email = m.group(2).trim();
						if (email.length() > 0) {
							emailAddress = email;
						}
					}
					continue;
				}
			}
			if (phoneNumber == null) {
				m = PATTERN_PHONE.matcher(line);
				if (m.find()) {
					if (m.groupCount() == 5) {
						StringBuilder sb = new StringBuilder();
						if (m.group(2) != null) {
							sb.append(String.format("%s", m.group(2).trim()));
						}
						sb.append(String.format("%s%s%s", m.group(3).trim(), m.group(4).trim(), m.group(5).trim()));
						phoneNumber = sb.toString();
					}
					continue;
				}
			}
			//if you did not find an explicit name and the line is before the phone # or email, hold it as a possible name line
			if (name == null && emailAddress == null && phoneNumber == null) {
				//skip any obvious non name lines
				if (!PATTERN_NOT_NAME.matcher(line).matches() && !PATTERN_PROB_IS_OTHER.matcher(line).matches() && PATTERN_POSSIBLE_NAME.matcher(line).matches()) {
					possibleNameLines.add(line);
				}
			}
		}
		//if no name yet and there is olny one line possible, assume it is the name
		if (name == null && possibleNameLines.size() == 1) {
			m = PATTERN_POSSIBLE_NAME.matcher(possibleNameLines.get(0));
			if (m.find()) {
				if (m.groupCount() == 1) {
					if (m.groupCount() == 1) {
						name = fmtNameLine(m.group(1));
					}
				}
			}
		}
		//if there is no name found yet and there is an email and candidate name lines, try to see if the name is part of the email
		if (name == null && emailAddress != null && !possibleNameLines.isEmpty()) {
			//take each name part from each possible line count how many times the parts are found in the email
			//assume that the line with the greatest hists is likely the name line

			//the sorted line number to hits map. sorted by the hit count
			TreeSet<Entry<Integer, Integer>> hitsMap = new TreeSet<>((Entry<Integer, Integer> o1, Entry<Integer, Integer> o2) -> {
				int valueComparison = -1 * o1.getValue().compareTo(o2.getValue());
				return valueComparison == 0 ? o1.getKey().compareTo(o2.getKey()) : valueComparison;
			});
			String[] emailParts = emailAddress.split("@");
			String emailPreAmp = emailParts[0].toLowerCase();
			int index = 0;
			for (String line : possibleNameLines) {
				List<String> namePieces = new ArrayList<>();
				String[] nameParts = line.split("\\s*,\\s*", 2);
				if (nameParts.length == 2) {
					String[] pieces = (nameParts[1] + " " + nameParts[0]).split("\\s+");
					namePieces.addAll(Arrays.asList(pieces));
				}
				else {
					String[] pieces = (nameParts[0]).split("\\s+");
					namePieces.addAll(Arrays.asList(pieces));
				}
				int hits = 0;
				hits = namePieces.stream().filter((x) -> (emailPreAmp.contains(x.toLowerCase()))).map((_item) -> 1).reduce(hits, Integer::sum);
				hitsMap.add(new AbstractMap.SimpleEntry<>(index++, hits));
			}
			Entry<Integer, Integer> firstEntry = hitsMap.first();
			//the line with the greates number of hits greater than 0 is assumed to be the name
			if (firstEntry != null && firstEntry.getValue() > 0) {
				m = PATTERN_POSSIBLE_NAME.matcher(possibleNameLines.get(firstEntry.getKey()));
				if (m.find()) {
					if (m.groupCount() == 1) {
						if (m.groupCount() == 1) {
							name = fmtNameLine(m.group(1));
						}
					}
				}
			}
			//email trick did not find a name line
			if (name == null) {
				hitsMap.forEach((e) -> {
					System.out.println(String.format("Possible name hits: %s line: %s", e.getValue(), possibleNameLines.get(e.getKey())));
				});
			}
		}
		if (name == null && !possibleNameLines.isEmpty()) {
			switch (possibleNameLines.size()) {
				case 1: {
					m = PATTERN_POSSIBLE_NAME.matcher(possibleNameLines.get(0));
					if (m.find()) {
						if (m.groupCount() == 1) {
							if (m.groupCount() == 1) {
								name = fmtNameLine(m.group(1));
							}
						}
					}
				}
				break;
				case 2: {
					m = PATTERN_POSSIBLE_NAME.matcher(possibleNameLines.get(0));
					if (m.find()) {
						if (m.groupCount() == 1) {
							if (m.groupCount() == 1) {
								name = fmtNameLine(m.group(1));
							}
						}
					}
				}
				break;
				case 3: {
					m = PATTERN_POSSIBLE_NAME.matcher(possibleNameLines.get(2));
					if (m.find()) {
						if (m.groupCount() == 1) {
							if (m.groupCount() == 1) {
								name = fmtNameLine(m.group(1));
							}
						}
					}
				}
				break;
				default: {
					m = PATTERN_POSSIBLE_NAME.matcher(possibleNameLines.get(1));
					if (m.find()) {
						if (m.groupCount() == 1) {
							if (m.groupCount() == 1) {
								name = fmtNameLine(m.group(1));
							}
						}
					}
				}
			}
		}
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getPhoneNumber() {
		return phoneNumber;
	}

	@Override
	public String getEmailAddress() {
		return emailAddress;
	}

}
