package BusinessCardParser;

/**
 *
 * @author Alex Loulou
 */
public interface ContactInfo {

	String getName();

	String getPhoneNumber();

	String getEmailAddress();
}
