package BusinessCardParser;

/**
 *
 * @author Alex Loulou
 */
public class TestDriver {

	public static void main(String[] args) {
		ContactInfo info = BusinessCardParser.getContactInfo("J B\nj.b@blow.com\n\n\n(301)-555-1212");
		System.out.println(String.format("Name:\t%s\nPhone:\t%s\nEmail:\t%s\n", info.getName(), info.getPhoneNumber(), info.getEmailAddress()));

		info = BusinessCardParser.getContactInfo("J B\nEmail: j.b@blow.com\n\n\n3015551212");
		System.out.println(String.format("Name:\t%s\nPhone:\t%s\nEmail:\t%s\n", info.getName(), info.getPhoneNumber(), info.getEmailAddress()));

		info = BusinessCardParser.getContactInfo("Entegra Systems\nJohn Doe\nSenior Software Engineer\n(410)555-1234\njohn.doe@entegrasystems.com");
		System.out.println(String.format("Name:\t%s\nPhone:\t%s\nEmail:\t%s\n", info.getName(), info.getPhoneNumber(), info.getEmailAddress()));

		info = BusinessCardParser.getContactInfo("Name: Jane Doe\nPhone: 4105551234\nEmail: jane.doe@acmetech.com");
		System.out.println(String.format("Name:\t%s\nPhone:\t%s\nEmail:\t%s\n", info.getName(), info.getPhoneNumber(), info.getEmailAddress()));

		info = BusinessCardParser.getContactInfo("Bob Smith\nSoftware Engineer\nDecision & Security Technologies\nABC Technologies\n123 North 11th Street\nSuite 229\nArlington, VA 22209\nTel: +1 (703) 555-1259\nFax: +1 (703) 555-1200\nbsmith@abctech.com");
		System.out.println(String.format("Name:\t%s\nPhone:\t%s\nEmail:\t%s\n", info.getName(), info.getPhoneNumber(), info.getEmailAddress()));

		info = BusinessCardParser.getContactInfo("Bob Smith\nSoftware Engineer\nDecision & Security Technologies\nABC Technologies\n123 North 11th Street\nSuite 229\nArlington, VA 22209\n+1 (703) 555-1259\nFax: +1 (703) 555-1200\nbsmith@abctech.com");
		System.out.println(String.format("Name:\t%s\nPhone:\t%s\nEmail:\t%s\n", info.getName(), info.getPhoneNumber(), info.getEmailAddress()));
	}

}
